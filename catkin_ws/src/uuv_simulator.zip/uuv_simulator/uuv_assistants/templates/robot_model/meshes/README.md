This folder is reserved to store the meshes for the vehicle, propeller and/or fins.

In the files they are named:

- vehicle.stl (vehicle's collision geometry)
- vehicle.dae (vehicle's visual geometry)
- propeller.dae (propeller mesh)
- fin.dae (fin/rudder mesh)
