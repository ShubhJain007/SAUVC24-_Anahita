# uuv_sensor_plugins: Simulated Sensors for UUVs

## Contents:

 - ```uuv_sensor_plugins```: Contains gazebo plugins for various simulated sensors.
 - ```uuv_sensor_ros_plugins```: ROS wrappers for each of the above.
 
